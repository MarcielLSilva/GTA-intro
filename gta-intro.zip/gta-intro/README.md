# GTA Intro (Fabric 26.3 snapshot)

Animação de entrada no mundo inspirada na troca de personagem do GTA V.

## Requisitos
- JDK 25 (JAVA_HOME apontando pra ele)
- Minecraft 26.3 (snapshot) + Fabric Loader + Fabric API 0.158.3+26.3

## Compilar
1. Gere o Gradle wrapper: `gradle wrapper --gradle-version latest`
   (ou copie `gradlew`, `gradlew.bat` e `gradle/` do Fabric Example Mod)
2. Confira as versões em https://fabricmc.net/develop e ajuste o `gradle.properties`
3. `./gradlew build` -> o .jar sai em `build/libs/`

## Ajustes
Em `IntroAnimation.java`: `DURATION`, `START_HEIGHT` e `SPIN_DEGREES`.
